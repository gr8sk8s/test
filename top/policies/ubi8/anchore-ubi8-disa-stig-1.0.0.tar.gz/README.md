### How to run

```
docker compose up -d

export TARGET_ID=$(docker ps --format json | jq -r '. | select(.Names == "my_ubi8_container") | .ID')

cinc-auditor exec anchore-redhat-enterprise-linux-8-disa-stig-1.0.0.tar.gz -t docker://$TARGET_ID --input-file=./ubi8-disa-stig.yml --reporter=cli json:./output.json
```