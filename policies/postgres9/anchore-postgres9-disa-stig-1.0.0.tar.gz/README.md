### How to run

```
docker compose up -d

export TARGET_ID=$(docker ps --format json | jq -r '. | select(.Names == "my_postgres_db") | .ID')

cinc-auditor exec anchore-postgres-9-disa-stig-1.0.0.tar.gz -t docker://$TARGET_ID --input-file=./postgres9.yml --reporter=cli json:./output.json
```